import numpy as np
import random

def func(x):
	f = ((5*x**3 - 3*x) / 2)**2
	return f

n=1000000
min_x = -1.0
max_x = 1.0
def integral(func, n):
	
	x = np.random.random(n) * (max_x - min_x) + min_x
	y = func(x)
	
	integral = np.average(y) * (max_x - min_x)
	return integral

i = 2/7

def errorP(integral, i):
	err = np.abs((integral(func, n) - i)/ i) * 100
	return err 


print ("la integral es ", integral(func, n))
print ("el valor real es ", i)
print ("el error porcentual es ", errorP(integral, i))
